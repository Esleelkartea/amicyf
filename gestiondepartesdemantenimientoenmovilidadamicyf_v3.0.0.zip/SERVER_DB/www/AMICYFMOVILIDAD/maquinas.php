<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="estilos.css" rel="stylesheet" type="text/css" />
<title>M&aacute;quinas</title>
</head>

<body>
<table width="230px" border="0" cellpadding="0" cellspacing="0" class="contenedor">
<tr><td align="right"><a href="salir.php">Salir</a></td></tr>
  <tr>
    <td align="center" valign="middle" class="centrar"><table  align="center" border="0" cellpadding="0" cellspacing="0" class="interior">
        <tr>
          <td class="textizqnegrita">M&aacute;quina</td>
        </tr>
        <tr>
          <td class="textizq">Aire Acondicionado Yamaha </td>
        </tr>
    </table>      </td>
  </tr>
  <tr>
    <td class="botones"><form action="modifi_maquinas.php" method="post"><input name="modificar" type="submit" class="botones" id="modificar" value="Modificar" /></form></td>
  </tr>
  
  
</table>

</body>
</html>
