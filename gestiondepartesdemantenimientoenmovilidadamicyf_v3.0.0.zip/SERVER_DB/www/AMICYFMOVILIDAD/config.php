<?php
  $_cfg['url'] = 'http://www.equipociclistaugeraga.com/';
  $_cfg['lang'] = 'es';
  $_cfg['theme'] = 'blackpedia';

  $_db['host'] = 'localhost';
  $_db['dbnm'] = 'soinus_sdugeraga';
  $_db['user'] = 'soinus';
  $_db['pass'] = 's01nus';
?>
