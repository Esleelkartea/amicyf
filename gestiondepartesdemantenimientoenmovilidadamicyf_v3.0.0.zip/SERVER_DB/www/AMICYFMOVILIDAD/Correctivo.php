<?php 
if (!class_exists('Correctivo'))
{
class Correctivo {
	var $numCorrectivo;
	var $fecha;
	var $contactoCorrectivo;
	var $incidenciaCorrectivo;
	var $solucionCorrectivo;   
	var $tiempoEstimadoCorrectivo;
	var $salida;
	var $costeSalida;
	var $importeMateriales;
	var $numHoras;
	var $numKilometros;
	var $importeHoras;
	var $importeKm;
	var $descuento;
	var $importeTotal;
	var $horaEntrada;
	var $horaSalida;
	function Correctivo() {
   }
}
}
?>
