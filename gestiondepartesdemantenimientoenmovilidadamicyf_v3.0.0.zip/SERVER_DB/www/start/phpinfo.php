<?php 




phpinfo();


?>